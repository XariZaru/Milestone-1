#include "TrainCrew.cpp"

class Train
{
private:
	float hoursTillArrival;
	float waitTimeStart;
	float totalTimeInQueue = 0;
	float timeInSystem = 0;
	int trainNum;
	float unloadingTime;
	bool startedUnloading = false;
	bool hoggedOut = false;
	float arrivalTime;

public:
	TrainCrew trainCrew;

	Train(float arrival, TrainCrew crew) : trainCrew(3)
	{
		hoursTillArrival = arrival;
		trainCrew = crew;
	}

	void startWaitTime(float currentTime)
	{
		waitTimeStart = currentTime;
	}

	float getHoursTillArrival()
	{
		return hoursTillArrival;
	}

	float getWaitTimeStart()
	{
		return waitTimeStart;
	}

	void updateTotalTimeInQueue(float currentTime)
	{
		totalTimeInQueue = currentTime - waitTimeStart;
		return;
	}

	float getTimeInQueue()
	{
		return totalTimeInQueue;
	}

	void updateTimeInSystem(float currentTime)
	{
		timeInSystem = currentTime - waitTimeStart;
		return;
	}

	float getTimeInSystem()
	{
		return timeInSystem;
	}

	void giveTrainNum(int num)
	{
		trainNum = num;
	}

	int getTrainNum()
	{
		return trainNum;
	}

	void setUnloadingTime(float time)
	{
		unloadingTime = time;
	}

	float getUnloadingTime()
	{
		return unloadingTime;
	}

	void trainIsUnloading()
	{
		startedUnloading = true;
	}

	bool hasStartedUnloading()
	{
		return startedUnloading;
	}

	void trainIsHoggedOut()
	{
		hoggedOut = true;
	}

	bool isHoggedOut()
	{
		return hoggedOut;
	}

	void setArrivalTime(float now)
	{
		arrivalTime = now;
	}

	float getArrivalTime()
	{
		return arrivalTime;
	}

};

struct TrainComp{
	bool operator()(Train& a, Train& b)
	{
		return a.getArrivalTime() > b.getArrivalTime();
	}
};

