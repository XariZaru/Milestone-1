class TrainCrew
{
private:
	float hoursToWork;
	float hoursTillArrival;
	float hogOutTime = 0;

public:
	
	TrainCrew(float hours)
	{
		hoursToWork = hours;
	}

	float remainingHours()
	{
		return hoursToWork;
	}

	void setNewRemainingHours(float time)
	{
		hoursToWork = time;
	}

	void callInNewCrew(float hours)
	{
		hoursTillArrival = hours;
	}

	float getHoursTillArrival()
	{
		return hoursTillArrival;
	}

	void setHogOutTime(float timeOfHogOut)
	{
		hogOutTime = timeOfHogOut;
	}

	float getHogOutTime()
	{
		return hogOutTime;
	}

};